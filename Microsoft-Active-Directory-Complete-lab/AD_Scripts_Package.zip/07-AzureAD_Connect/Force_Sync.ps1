Import-Module ADSync
Start-ADSyncSyncCycle -PolicyType Delta