New-GPO -Name "SecurityPolicy"
New-GPLink -Name "SecurityPolicy" -Target "OU=IT,DC=vlab,DC=local"
Backup-GPO -All -Path "C:\Backup\GPOs"