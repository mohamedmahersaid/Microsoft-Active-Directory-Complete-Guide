Install-WindowsFeature ADCS-Cert-Authority -IncludeManagementTools
Install-AdcsCertificationAuthority -CAType EnterpriseRootCA -CACommonName "RootCA" -KeyLength 2048 -HashAlgorithmName SHA256 -Force