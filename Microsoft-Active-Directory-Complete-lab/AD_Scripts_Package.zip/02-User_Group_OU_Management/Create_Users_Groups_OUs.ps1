New-ADOrganizationalUnit -Name "IT" -Path "DC=vlab,DC=local"
New-ADUser -Name "John Smith" -SamAccountName jsmith -AccountPassword (ConvertTo-SecureString "P@ssword1" -AsPlainText -Force) -Enabled $true
Add-ADGroupMember -Identity "Domain Admins" -Members jsmith